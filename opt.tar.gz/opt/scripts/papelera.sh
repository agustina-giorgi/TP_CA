#!/bin/bash

#Definir la ruta de la papelera
PAPELERA="/tmp/papelera"

#Manual de ayuda (--help)
mostrar_ayuda() {
    echo "================================================================="
    echo "MANUAL DE USO: PAPELERA DE RECICLAJE"
    echo "================================================================="
    echo "Uso: rm [ARCHIVO/DIRECTORIO] o [OPCIÓN]"
    echo ""
    echo "Descripción:"
    echo "  Este script reemplaza la eliminación permanente de Linux. Al usar 'rm',"
    echo "  los archivos se trasladan temporalmente a $PAPELERA."
    echo ""
    echo "Opciones disponibles:"
    echo "  -h, --help     Muestra el manual de ayuda."
    echo "  -v, --vaciar   Elimina PERMANENTEMENTE todos los archivos de la papelera."
    echo ""
    echo "Ejemplos:"
    echo "  rm mi_archivo.txt    -> Mueve el archivo a la papelera."
    echo "  rm --vaciar          -> Vacía por completo la papelera."
    echo "================================================================="
}

#Para vaciar la papelera
vaciar_papelera() {
    #Verificar si hay archivos adentro antes de preguntar
    if [ -z "$(ls -A "$PAPELERA")" ]; then
        echo "La papelera está vacía."
        exit 0
    fi

    echo "TENCIÓN: Se eliminarán TODOS los archivos de la papelera de manera permanente."
    read -p "¿Desea continuar? (y/n): " respuesta

    if [[ "$respuesta" == "y" || "$respuesta" == "Y" ]]; then
        \rm -rf "${PAPELERA}"/* "${PAPELERA}"/.[!.]* 2>/dev/null
        echo "Se ha vaciado la papelera de forma permanente."
    else
        echo "Operación cancelada. Los archivos permanecerán en la papelera."
    fi
}


if [ $# -eq 0 ]; then
    echo "rm: falta un argumento. Use 'rm --help' para más información."
    exit 1
fi


#Evaluar si el usuario ingresa --help o --vaciar
case "$1" in
    -h|--help)
        mostrar_ayuda
        exit 0
        ;;
    -v|--vaciar)
        vaciar_papelera
        exit 0
        ;;
esac


for ARCHIVO in "$@"; do
    #Ignorar parámetros como -r o -f si se escriben
    if [[ "$ARCHIVO" == -* ]]; then
        continue
    fi

    if [ -e "$ARCHIVO" ]; then
	RUTA_ABSOLUTA=$(readlink -f "$ARCHIVO")
        NOMBRE=$(basename "$ARCHIVO")

	if [[ "$RUTA_ABSOLUTA" == "$PAPELERA"* ]]; then
            read -p "Al confirmar, se eliminará de manera permanente. ¿Desea continuar? (y/n): " resp_individual
            
            if [[ "$resp_individual" == "y" || "$resp_individual" == "Y" ]]; then
                \rm -rf "$RUTA_ABSOLUTA"
                echo "Se ha eliminado el archivo de forma permanente."
            else
                echo "El archivo permanecerá en la papelera."
            fi
        else

        FECHA=$(date +"%Y%m%d_%H%M%S")
        #Mueve el archivo a la papelera y le agrega la fecha/hora al nombre
        mv "$ARCHIVO" "$PAPELERA/${FECHA}_${NOMBRE}"
        echo "El archivo '$NOMBRE' fue movido a la papelera (/tmp/papelera)."
	fi
    else
        echo "rm: no se puede borrar '$ARCHIVO': No existe el archivo o el directorio"
    fi
done
