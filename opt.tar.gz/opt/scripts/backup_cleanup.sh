#!/bin/bash

#Definir rutas
BACKUP_DIR="/backup_dir" #El directorio donde se guardan todos los backups
LOG_FILE="/var/log/backup_logs.log" #Donde se van a guardar los logs de backups
FECHA=$(date +"%Y-%m-%d %H:%M:%S") #Formato de fecha y hora

echo "=========================================" >> $LOG_FILE
echo "[$FECHA] INICIANDO CLEANUP DE BACKUPS" >> $LOG_FILE
echo "[$FECHA] Ejecutando limpieza de backups realizados hace más de 20 días..." >> $LOG_FILE

#Guardar la lista de lo que tiene más de 20 días para anotarlo en el log
ARCHIVOS_BORRADOS=$(find $BACKUP_DIR -type f -name "*.tar.gz" -mtime +20)

if [ -z "$ARCHIVOS_BORRADOS" ]; then
    echo "[$FECHA] No se encontraron backups realizados hace más de 20 días para borrar." >> $LOG_FILE
else
    echo "[$FECHA] Archivos eliminados:" >> $LOG_FILE
    echo "$ARCHIVOS_BORRADOS" >> $LOG_FILE
    #Ejecutar la eliminación real
    find $BACKUP_DIR -type f -name "*.tar.gz" -mtime +20 -delete
fi

echo "[$FECHA] CLEANUP FINALIZADO CON ÉXITO" >> $LOG_FILE
echo "=========================================" >> $LOG_FILE
