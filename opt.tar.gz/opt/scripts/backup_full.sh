#!/bin/bash

# Función para mostrar la ayuda (-help)
mostrar_ayuda() {
    echo "Uso: $0 [ORIGEN] [DESTINO]"
    echo ""
    echo "Descripción:"
    echo "  Este script realiza un backup comprimido (.tar.gz) del directorio de origen"
    echo "  y lo guarda en el directorio de destino con la fecha actual en formato ANSI."
    echo ""
    echo "Opciones:"
    echo "  -help    Muestra esta guía de uso."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /www_dir /backup_dir"
    exit 0
}

#Validar si el usuario pidió ayuda
if [ "$1" == "-help" ] || [ "$1" == "--help" ]; then
    mostrar_ayuda
fi

#Validar que se hayan pasado los dos argumentos requeridos
if [ -z "$1" ] || [ -z "$2" ]; then
    echo "ERROR: Faltan argumentos."
    mostrar_ayuda
fi

ORIGEN=$1
DESTINO=$2

#Validar que el directorio de ORIGEN exista
if [ ! -d "$ORIGEN" ]; then
    echo "ERROR: El directorio de origen '$ORIGEN' no existe o no está disponible."
    exit 1
fi

#Validar que el directorio de DESTINO exista
if [ ! -d "$DESTINO" ]; then
    echo "ERROR: El directorio de destino '$DESTINO' no existe o la partición no está montada."
    exit 1
fi

#Obtener la fecha en formato ANSI (AAAAMMDD)
FECHA=$(date +%Y%m%d)

#Definir el nombre y formato en el que se deben guardar los archivos backupeados
NOMBRE_ARCHIVO=$(basename "$ORIGEN")
NOMBRE_ARCHIVO_BKP="${NOMBRE_ARCHIVO}_bkp_${FECHA}.tar.gz"

echo "Iniciando backup de $ORIGEN en $DESTINO/$NOMBRE_ARCHIVO_BKP..."

#Ejecutar la compresión tar.gz
#Usar -C para ubicarse en el directorio padre y evitar guardar rutas absolutas muy largas
tar -czf "$DESTINO/$NOMBRE_ARCHIVO_BKP" -C "$(dirname "$ORIGEN")" "$NOMBRE_ARCHIVO"

# 8. Verificar si el tar se creó con éxito
if [ $? -eq 0 ]; then
    echo "¡Backup completado con éxito!"
else
    echo "ERROR: Hubo un fallo al crear el archivo de backup."
    exit 1
fi

