history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname set-hostname TPServer
poweroff
hostnamectl
hostname
bash
hostname
exit
hostnamectl set-hostname TPServer
exit
vi /etc/network/interfaces
systemctl restart networking
ip a
vi /etc/apt/sources.list
systemctl restart networking
reboot
apt update && apt full-upgrade -y
ping -c 4 8.8.8.8
ipconfig
vi /etc/network/interfaces
ping -c 4 8.8.8.8
vi /etc/network/interfaces
systemctl restart networking
ping -c 4 8.8.8.8
apt update && apt full-upgrade -y
reboot
vi /root/.ssh/authorized_keys
vi /etc/ssh/sshd_config
systemctl restart ssh
exit
exit
cat /root/clave_publica.pub >> /root/.ssh/authorized_keys
ls -la
cd .ssh
ls
type "C:\Users\Agustina\Documents\TP CA\clave_privada.txt" 
type "C:\Users\Agustina\Documents\TP\clave_privada.txt" 
cd authorized_keys 
cat authorized_keys
chmod 700 /root/.ssh
ls -la
chmod 600 /root/.ssh/authosized_keys
chmod 600 /root/.ssh/authorized_keys
ls -la
cat authorized_keys
type "C:\Users\Agustina\Documents\TP\clave_privada.txt"
exit
chown -R root:root /root/.ssh
ls -la
exit
cat /etc/debian-version
cat /etc/debian_version
apt install openssh-server
vi /etc/ssh/sshd_config
systemctl restart ssh
vi /root/.ssh/autorized?keys
rm /root/.ssh/autorized?keys
ls
ls ñl
ls -la
vi /etc/.ssh/authorized_keys
ls -la
cd .ssh
ls
ls -la
.
cd .
cd ..
ls -l
ls -la
chmod 700 /root/.ssh
ls -la
vi /etc/ssh/sshd_config
systemctl restart ssh
vi /etc/ssh/sshd_config
systemctl restart ssh
vi /etc/ssh/sshd_config
apt install apache2 && apt install mariadb
systemctl status apache2
apt install mariadb-server
reboot
systemctl status mariadb
poweroff
cat /proc/partitions > /root/particion
mv /root/particion /opt/particion
ls -la
ls -l /
cat proc
ls proc
cd proc
cat proc
cat opt
cat /opt/particion
ls opt
ls /opt
ls /home
ls /proc
ls /opt
cat /proc/partitions
ls /opt/particion
cat /opt/particion
dir
ls
exit
vi /etc/apache2/apache2.conf
systemctl restart apache2
apache2ctl configtest
vi /etc/apache2/apache2.conf
systemctl restart apache2
vi /etc/apache2/sites-available/000-default.conf
vi /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
php -v
mariadb
mariadb
exit
exit
ls -l /root/
mariadb < /root/db.sql
mariadb
a2enmod php*
apt install -y libapache2-mod-php
ls /etc/apache2/mods-available/ | grep php
a2enmod php8.2
systemctl restart apache2
vi /www_dir/index.php
tail -n 20 /var/log/apache2/error.log
vi /www_dir/index.php
apt install -y php8.2-mysql
phpenmod mysql
systemctl restart apache2
vi /www_dir/index.php
systemctl restart apache2
ls -l /www_dir/
umount /www_dir
umount /backup_dir
mount -a
df -h
cat /etc/fstab
poweroff
lsblk
fdisk /dev/sdc
fdisc /dev/sdc
fdisk /dev/sdc
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
lsblk
lsblk 'f
lsblk -f
mkdir /www_dir
mkdir /backup_dir
ls
ls 'la
ls -la
ls 'ld
ls -ld
ls -ld /www/dir
ls -ld /www_dir
ls -ld /backup_dir
ls -l /
lsblk -f
vi /etc/fstab
tail /etc/fstab
lsblk -f
mount -a
systemctl daemon-reload
mount -a
lsblk
lsblk -f
cat /proc/partitions
ls -l /www_dir
ls
ls -la
mv /root/index.php /www_dir/
ls -l /
ls -l /home
cat /www_dir/index.php
ls /www_dir/index.php
ls /www_dir
vi /etc/ssh/ssh_config
vi /etc/ssh/sshd_config
systemctl restart ssh
ls -l /www_dir
vi /etc/ssh/sshd_config
systemctl restart ssh
vi /etc/apache2/sites-available/000-default.conf
vi /etc/apache2/apache2.conf
vi /etc/ssh/sshd_config
systemctl restart ssh
ls 'l
ls -l
cat /root/db.sql
poweroff
exit
ls -la
ls -ld
ls -ld /
ls /
cd www_dir
cd /www_dir
ls
ls /
cd
ls /
ls -l /
cd /www_dir
ls -l
cd opt
cd /opt
ls -la
cd
cd
ls
ls -l
ls -la
mkdir -p /opt/scripts
ls -ld
ls -la
ls -l /
cd /opt
ls
cd
nano /opt/scripts/backup_full.sh
apt install nano
systemctl status nano
nano /opt/scripts/backup_full.sh
cd /opt/
ls -la
cd /scripts
cd scripts
ls
cat backup_full.sh
ls -l
chmod +x backup_full.sh
ls -l
cd
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls /backup_dir
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh --help
/opt/scripts/backup_ful.sh --help
/opt/scripts/backup_full.sh /www_dir /backup_di
nano /opt/scripts/backup_ful.sh
ls /opt/scripts
nano /opt/scripts/backup_full.sh
cat /opt/scripts/backup_full.sh
crontab -e
ls /var/logs
ls /var/log
df -h /backup_dir/www_dir_bkp_*.tar.gz
df -h /backup_dir
df -h
crontab -e
date
crontab -e
date
date
ate
date
ls -l /backup_dir
ls -l /backup_dir
crontab-e
crontab -e
nano /opt/scripts/backup_full.sh
crontab -e
date
date
date
date
date
ls -l /tmp/error_*.log
cat /tmp/error_www.log
cat /tmp/error_log.log
ls -lh /backup_dir
ls /tmp/error_*.log
rm /tmp/error_log.log
ls /tmp/error_*.log
rm /tmp/error_www.log
ls /tmp/error_*.log
ls /tmp/error
ls /tmp
clear
crontab -l
ls /opt/scripts
cd backup_full.sh
ls backup_full.sh
ls /backup_full.sh
ls -l /opt/scripts
ls -l /backup_dir
rm _bkp_20260614.tar.gz
rm /backup_dir/_bkp_20260614.tar.gz
ls -l /backup_dir
crontab -e
cat /opt/scripts/backup_full.sh
crontab -l
ls -lh /backup_dir
ls -l /backup_dir
nano /etc/ssh/sshd_config
cat /etc/ssh/sshd_config
exit
tar -tf /backup_dir/www_dir_bkp_20260614.tar.gz
df -h /backup_dir
df -h
nano /etc/ssh/sshd_config
nano /etc/network/interfaces
exit
ls -l /backup_dir
crontab -e
poweroff
mkdir /tmp/entrega_tp
tar -czf /tmp/entrega_tp/root.tar.gz /root
tar -czf /tmp/entrega_tp/etc.tar.gz /etc
tar -czf /tmp/entrega_tp/opt.tar.gz /opt
tar -czf /tmp/entrega_tp/www_dir.tar.gz /www_dir
tar -czf /tmp/entrega_tp/backup_dir.tar.gz /backup_dir
tar -czf - /var | split -b 40M - /tmp/entrega_tp/var.tar.gz.part_
ls -lh /tmp/entrega_tp
rm -rf /tmp/entrega_tp
ls /tmp
ls -l
ls -la
ls /opt
ls /particion
ls particion
cat particion
cat /particion
ls /particion
df -h
ls /backup_dir
ls /www_dir
ls /tmp
ls /.ssh
ls
ls -la
cd .ssh
ls
ls -la
cd
cd /.ssh/authorized_keys
cd /.ssh/
cd .ssh
ls
ls authorized_keys
ls -la authorized_keys
cat authorized_keys
ls /opt
cd
df -h
ls /backup_dir
mkdir /tmp/entrega_tp
ls /tmp
tar -czf /tmp/entrega_tp/root.tar.gz /root
tar -czf /tmp/entrega_tp/etc.tar.gz /etc
tar -czf /tmp/entrega_tp/opt.tar.gz /opt
tar -czf /tmp/entrega_tp/www_dir.tar.gz /www_dir
tar -czf /tmp/entrega_tp/backup_dir.tar.gz /backup_dir
tar -czf - /var | split -b 20M - /tmp/entrega_tp/var.tar.gz.part_
ls -lh /tmp/entrega_tp
exit
